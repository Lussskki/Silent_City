# Forest Floor Vol.1

4 seamless forest floor textures: leaf litter and pine needle ground, realistic and stylized. Tileable PNG, game-ready.

## Contents

- `forest_real_s403_seamless.png` — realistic forest floor
- `forest_styl_s503_seamless.png` — stylized forest floor
- `forest_leaves_s42.png` — forest floor, leaves variant
- `forest_pine_s42.png` — forest floor, pine variant

All textures are seamless/tileable PNG files. Drop them into your engine of
choice (Godot, Unity, GameMaker, Tiled...) and tile freely.

## License

Royalty-free. Use for any purposes, including commercial projects (games, jams, prototypes, videos, print). Modification allowed. You may NOT resell, sublicense, or redistribute the textures themselves as an asset or texture pack, modified or not. Credit appreciated but not required.

Tempisq asset pack - game-ready textures.
